# cloneWP 测试站恢复 0.1.0

仅用于 yaoxuxuan.com，不能在生产站使用。

1. 安装并启用依赖：WoodMart、WoodMart Core、Elementor、Elementor Pro、WooCommerce、Novamira。
2. 上传本插件并启用。PHP 需要 sodium；网站父目录必须可写，并且和 wp-content 位于同一文件系统。
3. 商品由用户自行上传；站点标题、时区、固定链接及搜索引擎收录设置均由用户手动决定。本插件不提供自动初始化入口。
4. 完成前台、编辑器、商品查询及 Novamira 连接验证后，“保存当前状态为初始基准”。
5. 以后复刻结束，打开同一页面，勾选确认并点击“恢复初始状态”。系统会先备份当前状态，再恢复基准。

恢复覆盖文章、页面、商品、分类、附件、菜单、页眉、模板和插件设置，以及 uploads、themes、plugins、mu-plugins 的文件。当前用户与认证信息保留。WordPress 核心、wp-config、服务器和 CDN 设置不在恢复范围内。

默认备份位于 WordPress 安装目录的父目录 `.clonewp-yaoxuxuan-vault`，数据库加密保存。不要删除 vault 或修改 AUTH salts。备份不自动清理，需监控空间。WordPress 版本、表前缀或恢复插件自身发生变化时，不能继续使用旧基准。

发生未知或部分恢复时，网站保持维护状态。管理员仍可登录并打开“工具 → 测试站恢复”，选择“恢复操作前备份”。磁盘或 PHP 本身故障仍需要服务器管理权限处理。

本地测试不能代替真实 WordPress/MySQL 恢复演练。只有目标站实测通过后，才能作为日常恢复工具使用。
